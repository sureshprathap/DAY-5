package templateMethod;

public interface Tax {
	
	public double calculate(Budget budget);

}
