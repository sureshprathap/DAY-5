package flyweight.notes;

import flyweight.Note;

public class Re implements Note {

	@Override
	public String simbol() {
		return "D";
	}

}
