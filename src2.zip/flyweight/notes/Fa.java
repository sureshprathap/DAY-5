package flyweight.notes;

import flyweight.Note;

public class Fa implements Note {

	@Override
	public String simbol() {
		return "F";
	}

}
