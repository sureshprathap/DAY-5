package flyweight.notes;

import flyweight.Note;

public class Mi implements Note {

	@Override
	public String simbol() {
		return "E";
	}

}
