package flyweight.notes;

import flyweight.Note;

public class Si implements Note {

	@Override
	public String simbol() {
		return "B";
	}

}
