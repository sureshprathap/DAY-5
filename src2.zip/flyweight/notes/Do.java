package flyweight.notes;

import flyweight.Note;

public class Do implements Note {

	@Override
	public String simbol() {
		return "C";
	}

}
