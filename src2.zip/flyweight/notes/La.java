package flyweight.notes;

import flyweight.Note;

public class La implements Note {

	@Override
	public String simbol() {
		return "A";
	}

}
