package flyweight;

import java.util.List;

public interface PlayMusic {
	
	public void play(List<Note> music);

}
