package flyweight;

public interface Note {
	
	public String simbol();

}
