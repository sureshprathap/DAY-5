package strategy;

public class Budget {

	private double value;

	Budget(double value) {
		super();
		this.value = value;
	}

	public double getValue() {
		return value;
	}

}
