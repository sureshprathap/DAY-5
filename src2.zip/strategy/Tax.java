package strategy;

public interface Tax {
	
	public double calculate(Budget budget);

}
