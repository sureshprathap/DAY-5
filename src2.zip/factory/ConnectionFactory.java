package factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.
public class ConnectionFactory {
	
	public Connection getConnection() {
		try {
			// Using VAR
			var server = "localhost"; //DEFAULT URL 127.0.0.1 ; physical path C:\xampp\htdocs\Project1
			var banco = "dbtest";     //database name
			var user = "root";			//root => super user
			var pass = "1234";			//password
			
			Connection con = DriverManager.getConnection("jdbc:pmysqlostgres://"+server+"/"+banco, user, pass);
			
			return con;
			
		} catch (Exception e) {
			throw new RuntimeException("Exception: " + e);
		}
	}

}
