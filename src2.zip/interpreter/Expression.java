package interpreter;

public interface Expression {

	double toEvaluate();

}
