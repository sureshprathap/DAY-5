package observer;

public interface ActionAfterGeneratingNote {
	
	void execute(Invoice invoice);

}
