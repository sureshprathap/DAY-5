package bridgesAndAdapters.adapter;

import java.time.LocalDate;

public interface IClock {
	
	public LocalDate today();

}
