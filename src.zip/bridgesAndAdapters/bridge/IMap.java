package bridgesAndAdapters.bridge;

public interface IMap {
	
	public String returnMap(String street);

}
