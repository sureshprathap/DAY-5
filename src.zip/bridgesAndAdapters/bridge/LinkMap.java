package bridgesAndAdapters.bridge;

public class LinkMap implements IMap{

	@Override
	public String returnMap(String street) {
		return "Link Map...";
	}

}
