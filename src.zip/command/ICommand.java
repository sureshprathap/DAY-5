package command;

public interface ICommand {
	
	void execute();

}
