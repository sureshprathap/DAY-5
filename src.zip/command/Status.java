package command;

public enum Status {
	
	NEW,
	PROCESSED,
	PAID_OUT,
	SEPARATE_ITEM,
	DELIVERED;

}
